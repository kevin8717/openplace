import{d as t,a,r as n,e as o}from"#entry";const c=t({__name:"default",setup(r){return(e,s)=>(o(),a("div",null,[n(e.$slots,"default")]))}});export{c as default};
