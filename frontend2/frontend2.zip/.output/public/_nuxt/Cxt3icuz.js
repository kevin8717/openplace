import{o}from"#entry";const n={__name:"index",setup(e){return o(()=>{location.replace(`/${location.search}`)}),()=>{}}};export{n as default};
